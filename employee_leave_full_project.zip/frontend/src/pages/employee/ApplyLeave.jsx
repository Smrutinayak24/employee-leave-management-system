import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { applyLeave } from "../../features/leaves/leaveSlice";

const ApplyLeave = () => {
  const [form, setForm] = useState({
    leaveType: "sick",
    startDate: "",
    endDate: "",
    reason: ""
  });
  const dispatch = useDispatch();
  const { loading, error } = useSelector((state) => state.leaves);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await dispatch(applyLeave(form));
  };

  return (
    <div style={{ maxWidth: 400, margin: "40px auto" }}>
      <h2>Apply Leave</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <select
          value={form.leaveType}
          onChange={(e) => setForm({ ...form, leaveType: e.target.value })}
        >
          <option value="sick">Sick</option>
          <option value="casual">Casual</option>
          <option value="vacation">Vacation</option>
        </select>
        <br />
        <label>Start Date</label>
        <input
          type="date"
          value={form.startDate}
          onChange={(e) => setForm({ ...form, startDate: e.target.value })}
          required
        />
        <br />
        <label>End Date</label>
        <input
          type="date"
          value={form.endDate}
          onChange={(e) => setForm({ ...form, endDate: e.target.value })}
          required
        />
        <br />
        <textarea
          placeholder="Reason"
          value={form.reason}
          onChange={(e) => setForm({ ...form, reason: e.target.value })}
          required
        />
        <br />
        <button disabled={loading}>Submit</button>
      </form>
    </div>
  );
};

export default ApplyLeave;
