import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchManagerDashboard } from "../../features/dashboard/dashboardSlice";

const ManagerDashboard = () => {
  const dispatch = useDispatch();
  const { manager, loading } = useSelector((state) => state.dashboard);

  useEffect(() => {
    dispatch(fetchManagerDashboard());
  }, [dispatch]);

  if (loading && !manager) return <p>Loading...</p>;

  return (
    <div style={{ padding: 20 }}>
      <h2>Manager Dashboard</h2>
      {manager && (
        <>
          <p>Employees: {manager.employeesCount}</p>
          <p>Pending Requests: {manager.pendingCount}</p>
          <p>Approved Requests: {manager.approvedCount}</p>
          <h3>Leave Days Used</h3>
          <p>Sick: {manager.typeStats.sick}</p>
          <p>Casual: {manager.typeStats.casual}</p>
          <p>Vacation: {manager.typeStats.vacation}</p>
        </>
      )}
    </div>
  );
};

export default ManagerDashboard;
