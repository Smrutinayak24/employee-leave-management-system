import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";

import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";

import EmployeeDashboard from "./pages/employee/EmployeeDashboard";
import ApplyLeave from "./pages/employee/ApplyLeave";
import MyRequests from "./pages/employee/MyRequests";

import ManagerDashboard from "./pages/manager/ManagerDashboard";
import PendingRequests from "./pages/manager/PendingRequests";
import AllRequests from "./pages/manager/AllRequests";

const App = () => {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<div style={{ padding: 20 }}>Welcome</div>} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route element={<ProtectedRoute role="employee" />}>
          <Route path="/employee/dashboard" element={<EmployeeDashboard />} />
          <Route path="/employee/apply" element={<ApplyLeave />} />
          <Route path="/employee/requests" element={<MyRequests />} />
        </Route>

        <Route element={<ProtectedRoute role="manager" />}>
          <Route path="/manager/dashboard" element={<ManagerDashboard />} />
          <Route path="/manager/pending" element={<PendingRequests />} />
          <Route path="/manager/all" element={<AllRequests />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default App;
