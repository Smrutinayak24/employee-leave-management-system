import LeaveRequest from "../models/LeaveRequest.js";
import User from "../models/User.js";

export const applyLeave = async (req, res) => {
  try {
    const { leaveType, startDate, endDate, reason } = req.body;

    const s = new Date(startDate);
    const e = new Date(endDate);
    const diffMs = e - s;
    if (diffMs < 0) {
      return res.status(400).json({ message: "endDate must be after startDate" });
    }
    const totalDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24)) + 1;

    const user = await User.findById(req.user._id);
    const balanceKey =
      leaveType === "sick" ? "sickLeave" : leaveType === "casual" ? "casualLeave" : "vacationLeave";

    if (user.leaveBalance[balanceKey] < totalDays) {
      return res.status(400).json({ message: "Insufficient leave balance" });
    }

    const leave = await LeaveRequest.create({
      userId: req.user._id,
      leaveType,
      startDate: s,
      endDate: e,
      totalDays,
      reason
    });

    res.status(201).json(leave);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};

export const myRequests = async (req, res) => {
  try {
    const leaves = await LeaveRequest.find({ userId: req.user._id }).sort({ createdAt: -1 });
    res.json(leaves);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};

export const cancelRequest = async (req, res) => {
  try {
    const leave = await LeaveRequest.findOne({
      _id: req.params.id,
      userId: req.user._id
    });

    if (!leave) return res.status(404).json({ message: "Leave not found" });
    if (leave.status !== "pending") {
      return res.status(400).json({ message: "Only pending leaves can be cancelled" });
    }

    await leave.deleteOne();
    res.json({ message: "Leave cancelled" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};

export const getMyBalance = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    res.json(user.leaveBalance);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};

export const getAllRequests = async (req, res) => {
  try {
    const leaves = await LeaveRequest.find()
      .populate("userId", "name email")
      .sort({ createdAt: -1 });
    res.json(leaves);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};

export const getPendingRequests = async (req, res) => {
  try {
    const leaves = await LeaveRequest.find({ status: "pending" })
      .populate("userId", "name email")
      .sort({ createdAt: 1 });
    res.json(leaves);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};

export const approveLeave = async (req, res) => {
  try {
    const leave = await LeaveRequest.findById(req.params.id);
    if (!leave) return res.status(404).json({ message: "Leave not found" });
    if (leave.status !== "pending") {
      return res.status(400).json({ message: "Only pending leaves can be approved" });
    }

    const user = await User.findById(leave.userId);
    const balanceKey =
      leave.leaveType === "sick"
        ? "sickLeave"
        : leave.leaveType === "casual"
        ? "casualLeave"
        : "vacationLeave";

    if (user.leaveBalance[balanceKey] < leave.totalDays) {
      return res.status(400).json({ message: "Insufficient balance at approval time" });
    }

    user.leaveBalance[balanceKey] -= leave.totalDays;
    await user.save();

    leave.status = "approved";
    leave.managerComment = req.body.managerComment || "";
    await leave.save();

    res.json(leave);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};

export const rejectLeave = async (req, res) => {
  try {
    const leave = await LeaveRequest.findById(req.params.id);
    if (!leave) return res.status(404).json({ message: "Leave not found" });
    if (leave.status !== "pending") {
      return res.status(400).json({ message: "Only pending leaves can be rejected" });
    }

    leave.status = "rejected";
    leave.managerComment = req.body.managerComment || "";
    await leave.save();

    res.json(leave);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};
