import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import api from "../../api/axios";

export const fetchMyRequests = createAsyncThunk(
  "leaves/fetchMyRequests",
  async (_, thunkAPI) => {
    try {
      const res = await api.get("/leaves/my-requests");
      return res.data;
    } catch (err) {
      return thunkAPI.rejectWithValue("Failed to load requests");
    }
  }
);

export const applyLeave = createAsyncThunk(
  "leaves/applyLeave",
  async (data, thunkAPI) => {
    try {
      const res = await api.post("/leaves", data);
      return res.data;
    } catch (err) {
      return thunkAPI.rejectWithValue(
        err.response?.data?.message || "Failed to apply leave"
      );
    }
  }
);

export const cancelLeave = createAsyncThunk(
  "leaves/cancelLeave",
  async (id, thunkAPI) => {
    try {
      await api.delete(`/leaves/${id}`);
      return id;
    } catch (err) {
      return thunkAPI.rejectWithValue("Failed to cancel leave");
    }
  }
);

export const fetchMyBalance = createAsyncThunk(
  "leaves/fetchMyBalance",
  async (_, thunkAPI) => {
    try {
      const res = await api.get("/leaves/balance");
      return res.data;
    } catch (err) {
      return thunkAPI.rejectWithValue("Failed to fetch balance");
    }
  }
);

const leaveSlice = createSlice({
  name: "leaves",
  initialState: {
    myRequests: [],
    balance: null,
    loading: false,
    error: null
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchMyRequests.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchMyRequests.fulfilled, (state, action) => {
        state.loading = false;
        state.myRequests = action.payload;
      })
      .addCase(fetchMyRequests.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(applyLeave.pending, (state) => {
        state.loading = true;
      })
      .addCase(applyLeave.fulfilled, (state, action) => {
        state.loading = false;
        state.myRequests.unshift(action.payload);
      })
      .addCase(applyLeave.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(cancelLeave.fulfilled, (state, action) => {
        state.myRequests = state.myRequests.filter((r) => r._id !== action.payload);
      })
      .addCase(fetchMyBalance.fulfilled, (state, action) => {
        state.balance = action.payload;
      });
  }
});

export default leaveSlice.reducer;
