import { useEffect, useState } from "react";
import api from "../../api/axios";

const PendingRequests = () => {
  const [requests, setRequests] = useState([]);

  const loadData = async () => {
    const res = await api.get("/leaves/pending");
    setRequests(res.data);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAction = async (id, action) => {
    const comment = window.prompt("Manager comment (optional)") || "";
    if (action === "approve") {
      await api.put(`/leaves/${id}/approve`, { managerComment: comment });
    } else {
      await api.put(`/leaves/${id}/reject`, { managerComment: comment });
    }
    loadData();
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Pending Requests</h2>
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>Employee</th>
            <th>Type</th>
            <th>Dates</th>
            <th>Total Days</th>
            <th>Reason</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {requests.map((r) => (
            <tr key={r._id}>
              <td>{r.userId?.name}</td>
              <td>{r.leaveType}</td>
              <td>
                {r.startDate?.slice(0, 10)} - {r.endDate?.slice(0, 10)}
              </td>
              <td>{r.totalDays}</td>
              <td>{r.reason}</td>
              <td>
                <button onClick={() => handleAction(r._id, "approve")}>
                  Approve
                </button>
                <button onClick={() => handleAction(r._id, "reject")}>
                  Reject
                </button>
              </td>
            </tr>
          ))}
          {!requests.length && (
            <tr>
              <td colSpan="6">No pending requests</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default PendingRequests;
