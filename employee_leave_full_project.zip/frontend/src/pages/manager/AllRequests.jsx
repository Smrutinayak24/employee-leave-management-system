import { useEffect, useState } from "react";
import api from "../../api/axios";

const AllRequests = () => {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    const load = async () => {
      const res = await api.get("/leaves/all");
      setRequests(res.data);
    };
    load();
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h2>All Requests</h2>
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>Employee</th>
            <th>Type</th>
            <th>Dates</th>
            <th>Total Days</th>
            <th>Status</th>
            <th>Manager Comment</th>
          </tr>
        </thead>
        <tbody>
          {requests.map((r) => (
            <tr key={r._id}>
              <td>{r.userId?.name}</td>
              <td>{r.leaveType}</td>
              <td>
                {r.startDate?.slice(0, 10)} - {r.endDate?.slice(0, 10)}
              </td>
              <td>{r.totalDays}</td>
              <td>{r.status}</td>
              <td>{r.managerComment}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AllRequests;
