import { configureStore } from "@reduxjs/toolkit";
import authReducer from "../features/auth/authSlice";
import leaveReducer from "../features/leaves/leaveSlice";
import dashboardReducer from "../features/dashboard/dashboardSlice";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    leaves: leaveReducer,
    dashboard: dashboardReducer
  }
});
