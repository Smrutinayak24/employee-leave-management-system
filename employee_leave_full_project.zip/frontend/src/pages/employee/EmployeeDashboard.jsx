import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchEmployeeDashboard } from "../../features/dashboard/dashboardSlice";
import { fetchMyBalance } from "../../features/leaves/leaveSlice";

const EmployeeDashboard = () => {
  const dispatch = useDispatch();
  const { employee, loading } = useSelector((state) => state.dashboard);
  const { balance } = useSelector((state) => state.leaves);

  useEffect(() => {
    dispatch(fetchEmployeeDashboard());
    dispatch(fetchMyBalance());
  }, [dispatch]);

  if (loading && !employee) return <p>Loading...</p>;

  return (
    <div style={{ padding: 20 }}>
      <h2>Employee Dashboard</h2>
      {employee && (
        <>
          <p>Total Requests: {employee.totalRequests}</p>
          <p>Approved Days Taken: {employee.totalTaken}</p>
          <p>Pending Requests: {employee.pendingCount}</p>
        </>
      )}
      {balance && (
        <>
          <h3>Leave Balance</h3>
          <p>Sick: {balance.sickLeave}</p>
          <p>Casual: {balance.casualLeave}</p>
          <p>Vacation: {balance.vacationLeave}</p>
        </>
      )}
    </div>
  );
};

export default EmployeeDashboard;
