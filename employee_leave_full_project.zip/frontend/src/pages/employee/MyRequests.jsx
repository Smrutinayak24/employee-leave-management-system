import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchMyRequests, cancelLeave } from "../../features/leaves/leaveSlice";

const MyRequests = () => {
  const dispatch = useDispatch();
  const { myRequests, loading } = useSelector((state) => state.leaves);

  useEffect(() => {
    dispatch(fetchMyRequests());
  }, [dispatch]);

  if (loading && !myRequests.length) return <p>Loading...</p>;

  return (
    <div style={{ padding: 20 }}>
      <h2>My Leave Requests</h2>
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>Type</th>
            <th>Dates</th>
            <th>Total Days</th>
            <th>Status</th>
            <th>Manager Comment</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {myRequests.map((r) => (
            <tr key={r._id}>
              <td>{r.leaveType}</td>
              <td>
                {r.startDate?.slice(0, 10)} - {r.endDate?.slice(0, 10)}
              </td>
              <td>{r.totalDays}</td>
              <td>{r.status}</td>
              <td>{r.managerComment}</td>
              <td>
                {r.status === "pending" && (
                  <button onClick={() => dispatch(cancelLeave(r._id))}>
                    Cancel
                  </button>
                )}
              </td>
            </tr>
          ))}
          {!myRequests.length && (
            <tr>
              <td colSpan="6">No requests yet</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default MyRequests;
