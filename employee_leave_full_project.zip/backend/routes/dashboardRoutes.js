import express from "express";
import { protect } from "../middleware/auth.js";
import { requireRole } from "../middleware/role.js";
import {
  getEmployeeDashboard,
  getManagerDashboard
} from "../controllers/dashboardController.js";

const router = express.Router();

router.get("/employee", protect, requireRole("employee"), getEmployeeDashboard);
router.get("/manager", protect, requireRole("manager"), getManagerDashboard);

export default router;
