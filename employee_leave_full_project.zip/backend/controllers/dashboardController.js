import LeaveRequest from "../models/LeaveRequest.js";
import User from "../models/User.js";

export const getEmployeeDashboard = async (req, res) => {
  try {
    const userId = req.user._id;

    const leaves = await LeaveRequest.find({ userId });

    const totalTaken = leaves
      .filter((l) => l.status === "approved")
      .reduce((sum, l) => sum + l.totalDays, 0);

    const pendingCount = leaves.filter((l) => l.status === "pending").length;

    res.json({
      totalRequests: leaves.length,
      totalTaken,
      pendingCount
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};

export const getManagerDashboard = async (req, res) => {
  try {
    const employeesCount = await User.countDocuments({ role: "employee" });
    const allLeaves = await LeaveRequest.find();

    const pendingCount = allLeaves.filter((l) => l.status === "pending").length;
    const approvedCount = allLeaves.filter((l) => l.status === "approved").length;

    const typeStats = allLeaves.reduce(
      (acc, l) => {
        acc[l.leaveType] = (acc[l.leaveType] || 0) + l.totalDays;
        return acc;
      },
      { sick: 0, casual: 0, vacation: 0 }
    );

    res.json({
      employeesCount,
      pendingCount,
      approvedCount,
      typeStats
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};
