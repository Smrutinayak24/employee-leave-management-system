import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import api from "../../api/axios";

export const fetchEmployeeDashboard = createAsyncThunk(
  "dashboard/fetchEmployee",
  async (_, thunkAPI) => {
    try {
      const res = await api.get("/dashboard/employee");
      return res.data;
    } catch {
      return thunkAPI.rejectWithValue("Failed to fetch employee dashboard");
    }
  }
);

export const fetchManagerDashboard = createAsyncThunk(
  "dashboard/fetchManager",
  async (_, thunkAPI) => {
    try {
      const res = await api.get("/dashboard/manager");
      return res.data;
    } catch {
      return thunkAPI.rejectWithValue("Failed to fetch manager dashboard");
    }
  }
);

const dashboardSlice = createSlice({
  name: "dashboard",
  initialState: {
    employee: null,
    manager: null,
    loading: false,
    error: null
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchEmployeeDashboard.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchEmployeeDashboard.fulfilled, (state, action) => {
        state.loading = false;
        state.employee = action.payload;
      })
      .addCase(fetchEmployeeDashboard.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(fetchManagerDashboard.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchManagerDashboard.fulfilled, (state, action) => {
        state.loading = false;
        state.manager = action.payload;
      })
      .addCase(fetchManagerDashboard.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  }
});

export default dashboardSlice.reducer;
