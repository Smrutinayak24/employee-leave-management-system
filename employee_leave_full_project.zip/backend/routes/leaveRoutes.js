import express from "express";
import { protect } from "../middleware/auth.js";
import { requireRole } from "../middleware/role.js";
import {
  applyLeave,
  myRequests,
  cancelRequest,
  getMyBalance,
  getAllRequests,
  getPendingRequests,
  approveLeave,
  rejectLeave
} from "../controllers/leaveController.js";

const router = express.Router();

router.post("/", protect, requireRole("employee"), applyLeave);
router.get("/my-requests", protect, requireRole("employee"), myRequests);
router.delete("/:id", protect, requireRole("employee"), cancelRequest);
router.get("/balance", protect, requireRole("employee"), getMyBalance);

router.get("/all", protect, requireRole("manager"), getAllRequests);
router.get("/pending", protect, requireRole("manager"), getPendingRequests);
router.put("/:id/approve", protect, requireRole("manager"), approveLeave);
router.put("/:id/reject", protect, requireRole("manager"), rejectLeave);

export default router;
