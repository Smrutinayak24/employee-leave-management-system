import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../features/auth/authSlice";

const Navbar = () => {
  const { user } = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  return (
    <nav style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>
      <Link to="/">Home</Link>
      {" | "}
      {user?.role === "employee" && (
        <>
          <Link to="/employee/dashboard">Dashboard</Link>{" | "}
          <Link to="/employee/apply">Apply Leave</Link>{" | "}
          <Link to="/employee/requests">My Requests</Link>
        </>
      )}
      {user?.role === "manager" && (
        <>
          <Link to="/manager/dashboard">Dashboard</Link>{" | "}
          <Link to="/manager/pending">Pending</Link>{" | "}
          <Link to="/manager/all">All Requests</Link>
        </>
      )}
      <span style={{ float: "right" }}>
        {user ? (
          <>
            {user.name} ({user.role}){" "}
            <button onClick={() => dispatch(logout())}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>{" | "}
            <Link to="/register">Register</Link>
          </>
        )}
      </span>
    </nav>
  );
};

export default Navbar;
